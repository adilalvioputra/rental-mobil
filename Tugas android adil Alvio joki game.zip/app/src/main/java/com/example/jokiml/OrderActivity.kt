package com.example.jokiml

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.example.jokiml.databinding.ActivityOrderBinding

class OrderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOrderBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOrderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Setup payment options
        val paymentOptions = arrayOf("Dana", "OVO", "GoPay", "Bank Transfer")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, paymentOptions)
        binding.spinnerPayment.adapter = adapter

        binding.btnSend.setOnClickListener {
            val name = binding.etName.text.toString()
            val userId = binding.etUserId.text.toString()
            val currentRank = binding.etCurrentRank.text.toString()
            val targetRank = binding.etTargetRank.text.toString()
            val paymentMethod = binding.spinnerPayment.selectedItem.toString()

            val message = """
                Halo Admin, saya ingin menggunakan jasa joki ML.
                Nama: $name
                ID ML: $userId
                Rank Sekarang: $currentRank
                Rank Target: $targetRank
                Metode Pembayaran: $paymentMethod
            """.trimIndent()

            val uri = Uri.parse("https://wa.me/6283818925249?text=" + Uri.encode(message))
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }
    }
}
